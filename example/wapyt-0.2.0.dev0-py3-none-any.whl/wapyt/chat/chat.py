import asyncio
import json
import logging
import inspect
from typing import Any, Callable, Dict, Iterable, List, Optional, Set, Union

from wapyt._runtime import js, create_proxy, require_js, to_plain
from wapyt.chat.chat_config import ChatConfig, ChatAgentConfig, ChatMessageConfig


logger = logging.getLogger(__name__)
WRAPPER_REVISION = "wapyt-chat-wrapper/2024-05-20"
logger.info("Chat widget wrapper loaded (%s)", WRAPPER_REVISION)
print(f"[ChatWidget] Wrapper ready ({WRAPPER_REVISION})")


class ChatStreamError(RuntimeError):
    """
    Raised when a backend stream yields an error payload instead of content.

    Streaming backends report provider failures in-band (see
    ``tests/multiaiproxy.py``), so a failed call still looks like a normal
    stream of chunks. Surfacing it as an exception routes it through the same
    handling as a transport error.
    """


class Chat:
    """
    Python wrapper around the custom Chat widget.

    Quick start::

        layout = Layout(LayoutConfig(rows=[CellConfig(id="chat", grow=1)]))
        chat = layout.add_chat("chat", ChatConfig())
        chat.on_send(lambda payload: print("User sent:", payload["text"]))

    The widget exposes helpers for streaming updates (`start_stream`,
    `append_stream`, `finish_stream`) so LLM-driven agents can incrementally
    render responses while work is still in progress.
    """

    def __init__(
        self,
        config: Optional[ChatConfig] = None,
        *,
        container: Any = None,
        root: Optional[Union[str, Any]] = None,
    ) -> None:
        require_js("Chat")
        if container is None and root is None:
            raise ValueError("Chat widget requires a container or a root element.")

        self.config = config or ChatConfig()
        self._container = container
        self._event_proxies: Dict[str, List[Any]] = {}

        root_element = self._resolve_root(container=container, root=root)
        if root_element is None:
            raise RuntimeError("Unable to resolve root element for Chat widget.")

        config_payload = self.config.to_dict()
        config_json = json.dumps(config_payload)
        config_options = js.JSON.parse(config_json)
        self.chat = js.wapyt.ChatWidget.new(root_element, config_options)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _js_class() -> Any:
        try:
            return js.wapyt.ChatWidget
        except AttributeError as exc:
            raise RuntimeError(
                "wapyt.ChatWidget is not available. Ensure the chat JavaScript bundle has been loaded."
            ) from exc

    def _resolve_root(self, *, container: Any, root: Optional[Union[str, Any]]) -> Any:
        target = container
        if target is not None:
            if hasattr(target, "getContainer"):
                return target.getContainer()
            if hasattr(target, "element"):
                return target.element
            return target
        if isinstance(root, str):
            element = js.document.querySelector(root)
            if not element:
                element = js.document.getElementById(root)
            return element
        return root

    def _bind_event(self, event_name: str, handler: Callable) -> None:
        def wrapped(*args, **kwargs):
            converted = [
                to_plain(arg)
                for arg in args
            ]
            return handler(*converted, **kwargs)

        proxy = create_proxy(wrapped)
        bucket = self._event_proxies.setdefault(event_name, [])
        bucket.append(proxy)
        self.chat.on(event_name, proxy)

    # ------------------------------------------------------------------
    # Event binding API
    # ------------------------------------------------------------------

    def on_send(self, handler: Callable[[Dict[str, Any]], Any]) -> None:
        """
        Fired when the user submits a prompt from the composer.

        The payload is ``{"id", "text", "message"}``: ``id`` is a fresh
        ``prompt-*`` identifier, ``text`` the trimmed prompt, and ``message``
        the user message dict (``role``, ``content``, ``name``, ``avatar``)
        that the widget appends to the transcript when
        ``auto_append_user_messages`` is on. Read the prompt from ``text``;
        there is no top-level ``content`` key.
        """
        self._bind_event("send", handler)

    def on_voice(self, handler: Callable[[Dict[str, Any]], Any]) -> None:
        """
        Fired when a push-to-talk recording finishes.

        The payload carries ``audio`` (base64 of the recorded container),
        ``mimeType`` (normally ``audio/webm;codecs=opus``), ``bytes`` and
        ``durationMs``. The widget does not transcribe -- hand the audio to a
        backend and feed the result back with :meth:`set_composer_text`.
        """
        self._bind_event("voice", handler)

    def on_voice_error(self, handler: Callable[[Dict[str, Any]], Any]) -> None:
        """
        Fired when capture could not start -- permission denied, no device, or a
        Permissions-Policy that blocks the microphone.
        """
        self._bind_event("voice:error", handler)

    def apply_transcript(self, text: str, *, submit: bool = False) -> None:
        """
        Write a transcript into the composer.

        Anything already typed is preserved as a prefix, and each transcript
        extends it -- so continuous dictation accumulates. ``submit`` sends the
        message immediately, which is what hands-free mode does.
        """
        self.chat.applyTranscript(
            "" if text is None else str(text),
            js.JSON.parse(json.dumps({"submit": bool(submit)})),
        )

    def set_composer_text(self, text: str, *, append: bool = False, submit: bool = False) -> None:
        """
        Put text into the composer. Used to deliver a transcript.

        ``append`` adds to what is already typed; ``submit`` sends immediately.
        """
        self.chat.setComposerText(
            "" if text is None else str(text),
            js.JSON.parse(json.dumps({"append": bool(append), "submit": bool(submit)})),
        )

    def on_artifact_save(self, handler: Callable[[Dict[str, Any]], Any]) -> None:
        """
        Fired when the user requests to save/download an artifact.
        """
        self._bind_event("artifact:save", handler)

    def on_artifact_load(self, handler: Callable[[Dict[str, Any]], Any]) -> None:
        """
        Fired after a user picks a file to load into the artifact preview pane.
        """
        self._bind_event("artifact:load", handler)

    def on_copy(self, handler: Callable[[Dict[str, Any]], Any]) -> None:
        """
        Fired when the user clicks the per-message copy button.
        """
        self._bind_event("copy", handler)

    # ------------------------------------------------------------------
    # Data operations
    # ------------------------------------------------------------------

    @staticmethod
    def _message_to_dict(
        message: Union[ChatMessageConfig, Dict[str, Any]]
    ) -> Dict[str, Any]:
        if hasattr(message, "to_dict"):
            return message.to_dict()
        if isinstance(message, dict):
            return message
        raise TypeError(f"Unsupported chat message type: {type(message)!r}")

    def set_messages(
        self, messages: Iterable[Union[ChatMessageConfig, Dict[str, Any]]]
    ) -> None:
        payload = [self._message_to_dict(message) for message in messages]
        self.chat.setMessages(js.JSON.parse(json.dumps(payload)))

    def add_message(
        self, message: Union[ChatMessageConfig, Dict[str, Any]]
    ) -> str:
        payload = self._message_to_dict(message)
        result = self.chat.addMessage(js.JSON.parse(json.dumps(payload)))
        return to_plain(result)

    def update_message(self, message_id: str, **updates: Any) -> None:
        self.chat.updateMessage(
            message_id,
            js.JSON.parse(json.dumps(updates))
        )

    def remove_message(self, message_id: str) -> None:
        if hasattr(self.chat, "removeMessage"):
            self.chat.removeMessage(message_id)

    def clear_messages(self) -> None:
        self.chat.clearMessages()

    # ------------------------------------------------------------------
    # Streaming helpers
    # ------------------------------------------------------------------

    def start_stream(
        self,
        message: Union[ChatMessageConfig, Dict[str, Any]],
    ) -> str:
        payload = self._message_to_dict(message)
        result = self.chat.startStream(js.JSON.parse(json.dumps(payload)))
        return to_plain(result)

    def append_stream(self, message_id: str, chunk: str) -> None:
        self.chat.appendStream(message_id, chunk)

    def finish_stream(self, message_id: str, final_chunk: Optional[str] = None) -> None:
        if final_chunk is None:
            self.chat.finishStream(message_id)
        else:
            self.chat.finishStream(message_id, final_chunk)

    # ------------------------------------------------------------------
    # Appearance / metadata
    # ------------------------------------------------------------------

    def set_agent(self, agent: Union[ChatAgentConfig, Dict[str, Any]]) -> None:
        if hasattr(agent, "to_dict"):
            agent_payload = agent.to_dict()
        elif isinstance(agent, dict):
            agent_payload = agent
        else:
            raise TypeError(f"Unsupported agent representation: {type(agent)!r}")
        self.chat.setAgent(js.JSON.parse(json.dumps(agent_payload)))

    def set_extra(self, extra: Dict[str, Any]) -> None:
        """
        Replace the model catalogue after construction and rebuild the selector.

        ``extra`` accepts ``providerConfig`` (a ``{"providers": {...}}`` mapping)
        and/or ``models`` (a flat list). Apps normally load their provider list
        from a backend after the widget already exists, so without this the model
        dropdown stays frozen at whatever was passed to the constructor.
        """
        if not isinstance(extra, dict):
            raise TypeError(f"extra must be a dict, got {type(extra)!r}")
        self.chat.setExtra(js.JSON.parse(json.dumps(extra)))

    def set_models(self, models: List[str]) -> None:
        self.set_extra({"models": list(models)})

    def set_theme(self, theme: str) -> None:
        self.chat.setTheme(theme)

    def focus_composer(self) -> None:
        if hasattr(self.chat, "focusComposer"):
            self.chat.focusComposer()

    def set_chat_badge(self, chat_id: str, badge: Optional[int]) -> None:
        if not chat_id:
            raise ValueError("chat_id is required to set a badge")
        self.chat.setChatBadge(chat_id, badge)

    def get_chats(self) -> List[Dict[str, Any]]:
        return to_plain(self.chat.getChats())

    def get_messages(self, chat_id: Optional[str] = None) -> List[Dict[str, Any]]:
        if chat_id is None:
            result = self.chat.getMessages()
        else:
            result = self.chat.getMessages(chat_id)
        return to_plain(result)

    # ------------------------------------------------------------------
    # Conversation helpers
    # ------------------------------------------------------------------

    def build_history(
        self,
        *,
        chat_id: Optional[str] = None,
        system_prompt: Optional[str] = None,
        exclude_ids: Optional[Iterable[str]] = None,
        include_empty: bool = False,
    ) -> List[Dict[str, str]]:
        excluded: Set[str] = set(exclude_ids or [])
        history: List[Dict[str, str]] = []

        if system_prompt:
            history.append({"role": "system", "content": system_prompt})

        for entry in self.get_messages(chat_id):
            if not isinstance(entry, dict):
                continue
            if entry.get("id") in excluded:
                continue
            content = (entry.get("content") or "")
            if not include_empty and not content.strip():
                continue
            role = (entry.get("role") or "assistant").lower()
            if role not in {"user", "assistant", "system"}:
                role = "assistant"
            history.append({"role": role, "content": content})

        return history

    @staticmethod
    def _delta_text(delta: Any) -> str:
        """
        Pull the text out of a provider ``delta`` field (dict or bare string).
        """
        if isinstance(delta, dict):
            return str(delta.get("content") or delta.get("text") or "")
        return str(delta) if delta else ""

    @staticmethod
    def extract_stream_error(chunk: Any) -> Optional[str]:
        """
        Return a human-readable message when ``chunk`` is an error payload.

        Returns ``None`` for ordinary content chunks.
        """
        payload = chunk
        if hasattr(payload, "model_dump"):
            payload = payload.model_dump(exclude_none=True)
        elif hasattr(payload, "to_dict"):
            payload = payload.to_dict()

        if not isinstance(payload, dict):
            return None

        error = payload.get("error")
        if error is None and payload.get("type") == "error":
            error = payload
        if error is None:
            return None
        if isinstance(error, dict):
            message = error.get("message") or error.get("detail") or error.get("code")
            return str(message) if message else "Unknown backend error"
        return str(error) if error else "Unknown backend error"

    @staticmethod
    def extract_stream_text(chunk: Any) -> str:
        if chunk is None:
            return ""

        if isinstance(chunk, str):
            return chunk

        payload = chunk
        if hasattr(payload, "model_dump"):
            payload = payload.model_dump(exclude_none=True)
        elif hasattr(payload, "to_dict"):
            payload = payload.to_dict()

        if isinstance(payload, str):
            return payload

        if not isinstance(payload, dict):
            return ""

        chunk_type = payload.get("type")

        if chunk_type == "chunk":
            payload = payload.get("chunk", {})
            choices = payload.get("choices") or []
        elif chunk_type in ("content.delta", "response.output_text.delta"):
            # Proxies that normalize deltas into `choices` never emit these, but
            # a proxy that forwards provider chunks verbatim does; returning ""
            # here silently dropped the whole response.
            return Chat._delta_text(payload.get("delta"))
        else:
            choices = payload.get("choices")
            if choices is None and "chunk" in payload:
                choices = payload["chunk"].get("choices")

        if not choices:
            return ""

        for choice in choices:
            delta = (choice or {}).get("delta")
            if not delta:
                continue
            if isinstance(delta, str):
                return delta
            if isinstance(delta, dict):
                text = delta.get("content")
                if text:
                    return text
        return ""

    def consume_stream(
        self,
        response_id: str,
        stream: Any,
        *,
        parser: Optional[Callable[[Any], str]] = None,
        finish: bool = True,
        on_error: Optional[Callable[[Exception], None]] = None,
    ) -> None:
        tokenize = parser or self.extract_stream_text

        def handle_error(exc: Exception) -> None:
            if on_error:
                on_error(exc)
                return
            warning = f"Backend error: {exc}"
            try:
                self.append_stream(response_id, warning)
            finally:
                self.finish_stream(response_id)
            logger.warning("[Chat] stream failed: %s", exc)

        def text_of(chunk: Any) -> str:
            # A backend that fails mid-stream yields an error payload rather
            # than raising, so check for one before extracting text.
            message = self.extract_stream_error(chunk)
            if message:
                raise ChatStreamError(message)
            return tokenize(chunk)

        if inspect.isasyncgen(stream) or (
            hasattr(stream, "__aiter__") and not hasattr(stream, "__iter__")
        ):

            async def runner():
                try:
                    async for chunk in stream:
                        text = text_of(chunk)
                        if text:
                            self.append_stream(response_id, text)
                except Exception as exc:  # pragma: no cover - pass to handler
                    handle_error(exc)
                else:
                    if finish:
                        self.finish_stream(response_id)

            self._run_async(runner())
            return

        try:
            iterator = iter(stream)
        except TypeError:
            raise ValueError("stream must be an iterable or async iterable") from None

        try:
            for chunk in iterator:
                text = text_of(chunk)
                if not text:
                    continue
                self.append_stream(response_id, text)
        except Exception as exc:  # pragma: no cover - pass to handler
            handle_error(exc)
            return

        if finish:
            self.finish_stream(response_id)

    @staticmethod
    def _run_async(coro) -> None:
        """
        Schedule ``coro`` without blocking the caller.

        `consume_stream` is normally reached from a synchronous JS event
        handler, where `get_running_loop` fails even though Pyodide's WebLoop is
        installed. `asyncio.run` must not be used there: it creates a *new* loop
        and closes it on exit, which breaks the WebLoop for the rest of the
        session, and it cannot block on a browser event loop in any case.
        `ensure_future` schedules onto the existing loop and lets the browser
        drive it.
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop is not None:
            loop.create_task(coro)
            return

        if js is not None:  # Pyodide
            asyncio.ensure_future(coro)
            return

        # CPython (tests/offline): no loop to borrow, so run one to completion.
        asyncio.run(coro)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def destroy(self) -> None:
        try:
            if hasattr(self.chat, "destroy"):
                self.chat.destroy()
        finally:
            self._event_proxies.clear()
